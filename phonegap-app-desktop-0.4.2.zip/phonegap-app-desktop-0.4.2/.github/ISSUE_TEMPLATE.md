## _System Configuration_

### PhoneGap Desktop version

### PhoneGap Mobile App version

### Mobile devices & Mobile OS version

### Computer OS version

### Network Type (home/corporate)

### Is your network using a proxy?

### Computer / Network security (firewall / anti-virus / disk encryption)

### Are you using VMs on your computer?

### Do you have multiple network adapters (or virtual network adapters)?

### Are you using VPN?

### Expected Behaviour

### Actual Behaviour

### Steps to Reproduce 

#### Error messages
