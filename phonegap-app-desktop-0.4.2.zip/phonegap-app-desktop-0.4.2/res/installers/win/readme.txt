Windows Installer Script requires Inno Setup to compile.

- load pg-desktop.iss into Inno Setup
- compile the pg-desktop.iss file
- it will generate a setup.exe file in the following location: C:\Users\<username>\Documents\Inno Setup Examples Output